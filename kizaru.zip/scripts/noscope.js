UI.AddCheckbox(
  ["Rage", "SUBTAB_MGR", "Accuracy", "SHEET_MGR", "General"],
  "Disable autoscope if target is close"
);
UI.AddSliderInt(
  ["Rage", "SUBTAB_MGR", "Accuracy", "SHEET_MGR", "General"],
  "Minimum distance to disable autoscope",
  0,
  100
);

var target = -1;

function CreateMove() {
  localplayer = Entity.GetLocalPlayer();
  localplayer_weapon = Entity.GetWeapon(localplayer);
  currentweapon = Entity.GetName(localplayer_weapon);
  if (currentweapon === "g3sg1") {
    currentweapon = "G3SG1";
  } else if (currentweapon === "awp") {
    currentweapon = "AWP";
  } else if (currentweapon === "scar 20") {
    currentweapon = "SCAR20";
  } else if (currentweapon === "ssg 08") {
    currentweapon = "SSG08";
  }

  configgedweapons = UI.GetChildren([
    "Rage",
    "SUBTAB_MGR",
    "Accuracy",
    "SHEET_MGR",
  ]);
  //Cheat.Print(configgedweapons.indexOf(currentweapon) + "\n" + currentweapon + "\n");
  //Cheat.Print(configgedweapons.toString());
  if (configgedweapons.indexOf(currentweapon) === -1) {
    //Cheat.Print("Couldn't Find Weapon!\n");
    currentweapon = "General";
  }
  //Cheat.Print(configgedweapons + "\n" + currentweapon + "\n");

  if (!Ragebot.GetTarget()) target = closestTarget();
  else target = Ragebot.GetTarget();
  if (!Entity.IsAlive(target)) {
    UI.SetValue(
      [
        "Rage",
        "SUBTAB_MGR",
        "Accuracy",
        "SHEET_MGR",
        currentweapon,
        "Auto scope",
      ],
      1
    );
    return;
  }
  if (
    get_metric_distance(
      Entity.GetRenderOrigin(Entity.GetLocalPlayer()),
      Entity.GetRenderOrigin(target)
    ) <
    UI.GetValue([
      "Rage",
      "SUBTAB_MGR",
      "Accuracy",
      "SHEET_MGR",
      "General",
      "Minimum distance to disable autoscope",
    ])
  ) {
    //Cheat.Print("Autoscope is off!");
    UI.SetValue(
      [
        "Rage",
        "SUBTAB_MGR",
        "Accuracy",
        "SHEET_MGR",
        currentweapon,
        "Auto scope",
      ],
      0
    );
  } else {
    UI.SetValue(
      [
        "Rage",
        "SUBTAB_MGR",
        "Accuracy",
        "SHEET_MGR",
        currentweapon,
        "Auto scope",
      ],
      1
    );
  }
}
Cheat.RegisterCallback("CreateMove", "CreateMove");
function closestTarget() {
  var local = Entity.GetLocalPlayer();
  var enemies = Entity.GetEnemies();
  var dists = [];
  var damage = [];
  for (e in enemies) {
    if (
      !Entity.IsAlive(enemies[e]) ||
      Entity.IsDormant(enemies[e]) ||
      !Entity.IsValid(enemies[e])
    )
      continue;
    dists.push([
      enemies[e],
      calcDist(
        Entity.GetHitboxPosition(local, 0),
        Entity.GetHitboxPosition(enemies[e], 0)
      ),
    ]);
  }
  dists.sort(function (a, b) {
    return a[1] - b[1];
  });
  if (dists.length == 0 || dists == []) return (target = -1);
  return dists[0][0];
}

// clean dist func, thanks rzr
function calcDist(a, b) {
  x = a[0] - b[0];
  y = a[1] - b[1];
  z = a[2] - b[2];
  return Math.sqrt(x * x + y * y + z * z);
}

function get_metric_distance(a, b) {
  return Math.floor(
    Math.sqrt(
      Math.pow(a[0] - b[0], 2) +
        Math.pow(a[1] - b[1], 2) +
        Math.pow(a[2] - b[2], 2)
    ) * 0.0254
  );
}